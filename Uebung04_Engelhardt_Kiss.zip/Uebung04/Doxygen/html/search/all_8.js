var searchData=
[
  ['name_0',['name',['../class_type.html#ab4f0dda37f7a94508565f207638a7dcc',1,'Type::name'],['../class_var.html#ad112053ba9381eb7b8b26b3c5702410a',1,'Var::name']]]
];
