var searchData=
[
  ['javatype_0',['JavaType',['../class_java_type.html',1,'']]],
  ['javavar_1',['JavaVar',['../class_java_var.html',1,'']]]
];
