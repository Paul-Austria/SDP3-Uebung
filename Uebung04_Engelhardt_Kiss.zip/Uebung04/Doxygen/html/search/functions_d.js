var searchData=
[
  ['var_0',['var',['../class_var.html#aca569deb0c42f7addeb44a459681c2d0',1,'Var::Var(std::string name, std::shared_ptr&lt; Type &gt; type)'],['../class_var.html#a7a6b0f2937f429b29a76df6afe80998a',1,'Var::Var()=default']]]
];
