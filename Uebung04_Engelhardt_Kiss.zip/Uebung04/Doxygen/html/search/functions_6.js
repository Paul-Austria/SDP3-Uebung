var searchData=
[
  ['javatype_0',['JavaType',['../class_java_type.html#aafc89da92049374af66bb99cba43d7b5',1,'JavaType']]],
  ['javavar_1',['JavaVar',['../class_java_var.html#a0fc7f3d7d72845e56b4f193b31ab8660',1,'JavaVar']]]
];
