var searchData=
[
  ['type_0',['type',['../class_var.html#acc0a7d4c456b313157e1a9842d58ff28',1,'Var']]]
];
