/* File: Motorrad.cpp
*  Creator: Paul Engelhardt
*/
#include "Motorrad.hpp"





std::string Motorrad::GetVehicleType() const
{
	return "Motorrad";
}
