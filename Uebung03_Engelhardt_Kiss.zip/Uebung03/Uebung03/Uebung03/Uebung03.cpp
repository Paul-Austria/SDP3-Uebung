/* File Uebung03.cpp
*  Creator: Paul Engelhardt
*/
#include <iostream>
#include "Client.hpp"
int main() {
    Client client;
    client.TestPlayers();
    return 0;
}
