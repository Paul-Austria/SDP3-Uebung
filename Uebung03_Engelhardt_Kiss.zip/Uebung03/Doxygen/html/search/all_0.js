var searchData=
[
  ['add_0',['add',['../class_music_player.html#aed8cdbc7bd8f9bc25d15cb3f36a5a43f',1,'MusicPlayer::Add()'],['../class_video_player.html#a66dbee09db0015378080d2563307673f',1,'VideoPlayer::Add()']]]
];
