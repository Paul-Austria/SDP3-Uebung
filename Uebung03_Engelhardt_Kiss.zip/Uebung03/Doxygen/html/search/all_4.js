var searchData=
[
  ['getcount_0',['GetCount',['../class_music_player.html#a9f1af67041e460e9f05da283d7df9202',1,'MusicPlayer']]],
  ['getcurindex_1',['GetCurIndex',['../class_music_player.html#acb8265daab8ee1669b2d36d01a67a65a',1,'MusicPlayer']]],
  ['getduration_2',['getduration',['../class_song.html#ac831ab12b66640919e532be2e34869ac',1,'Song::GetDuration()'],['../class_video.html#ac5563431085d7c878a0dbfbe5fbd5a16',1,'Video::GetDuration()']]],
  ['getname_3',['getname',['../class_song.html#a7ffd20aefbfcf9db002dc5bec71f8b90',1,'Song::GetName()'],['../class_video.html#afbcc73532279adfb1ea3fd714c5f92c2',1,'Video::GetName() const']]],
  ['getvideoformat_4',['GetVideoFormat',['../class_video.html#a1537f665e2aac71c7ee762e7caf4b39d',1,'Video']]],
  ['getvolume_5',['GetVolume',['../class_video_player.html#af7a343871ec258028abf906f4c9a994d',1,'VideoPlayer']]]
];
