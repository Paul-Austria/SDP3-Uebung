var searchData=
[
  ['client_0',['client',['../class_client.html',1,'Client'],['../class_client.html#ac13ad1e98c47db57ce0823dc735261cd',1,'Client::Client()']]],
  ['curindex_1',['CurIndex',['../class_video_player.html#a48fbc84bc65e973e927cd8beb578ef17',1,'VideoPlayer']]],
  ['curvideo_2',['CurVideo',['../class_video_player.html#a23af7a0a33fb72988050e91a8ea31529',1,'VideoPlayer']]]
];
