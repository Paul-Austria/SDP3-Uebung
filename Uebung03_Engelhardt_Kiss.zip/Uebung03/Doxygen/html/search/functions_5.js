var searchData=
[
  ['imediawrapper_0',['IMediaWrapper',['../class_i_media_wrapper.html#a0623ba34c4ce09553d222f3b9d0edef3',1,'IMediaWrapper']]],
  ['increasevol_1',['IncreaseVol',['../class_music_player.html#af92f42737365bbbe930b8490c11ac687',1,'MusicPlayer']]]
];
