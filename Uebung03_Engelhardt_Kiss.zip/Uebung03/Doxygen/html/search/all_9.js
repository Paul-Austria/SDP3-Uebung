var searchData=
[
  ['play_0',['play',['../class_i_media_wrapper.html#a304fc6f11b6f5f6e9ff15bf70b64b266',1,'IMediaWrapper::Play()'],['../class_music_player_wrapper.html#a2cda21e00f6cc936c41f018822a985c6',1,'MusicPlayerWrapper::Play()'],['../class_video_player.html#a18c39f0d65b9c3fc0f7943020126938e',1,'VideoPlayer::Play()'],['../class_video_player_wrapper.html#af699b398291102d34ca2de86612c12dc',1,'VideoPlayerWrapper::Play()']]],
  ['prev_1',['prev',['../class_i_media_wrapper.html#add2278d8b6a06f04ea221b4b2d5250e3',1,'IMediaWrapper::Prev()'],['../class_music_player_wrapper.html#a340deba2b4c64a1f057dd7b8046e67f4',1,'MusicPlayerWrapper::Prev()'],['../class_video_player_wrapper.html#a704f53499e1af79834daee3b2de0fea4',1,'VideoPlayerWrapper::Prev()']]]
];
