var searchData=
[
  ['testplayers_0',['TestPlayers',['../class_client.html#a3ed6ffdfaea320407be8f5441e95ad97',1,'Client']]]
];
