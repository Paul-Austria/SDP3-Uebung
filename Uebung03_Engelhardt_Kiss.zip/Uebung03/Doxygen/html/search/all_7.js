var searchData=
[
  ['next_0',['next',['../class_i_media_wrapper.html#a6b2855d7e5a81d1d0994547fe66c2a0b',1,'IMediaWrapper::Next()'],['../class_music_player_wrapper.html#a8d4c0128843fd4c48a5add87611f5f60',1,'MusicPlayerWrapper::Next()'],['../class_video_player.html#af27c8ff39bbb0214293ce3ecef13f29d',1,'VideoPlayer::Next()'],['../class_video_player_wrapper.html#a554713f45156fbefb09ceead97df4bf3',1,'VideoPlayerWrapper::Next()']]]
];
