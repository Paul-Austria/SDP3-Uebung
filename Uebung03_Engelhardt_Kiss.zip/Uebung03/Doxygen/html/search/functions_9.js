var searchData=
[
  ['select_0',['select',['../class_i_media_wrapper.html#a61a72195acc0989cbd75732e3c8b5531',1,'IMediaWrapper::Select()'],['../class_music_player_wrapper.html#a9edda244b9302945a54bb79eebc60134',1,'MusicPlayerWrapper::Select()'],['../class_video_player_wrapper.html#a9cfe61e36d6e2e653767996360a027e9',1,'VideoPlayerWrapper::Select()']]],
  ['setvolume_1',['SetVolume',['../class_video_player.html#abdd0e2b7d41aa7dec197ad2d8774fd64',1,'VideoPlayer']]],
  ['song_2',['Song',['../class_song.html#a029aa54e4978da20f6c0770ff3608c01',1,'Song']]],
  ['start_3',['Start',['../class_music_player.html#a73e800c81fde41edcac80734844e6204',1,'MusicPlayer']]],
  ['stop_4',['stop',['../class_i_media_wrapper.html#a6cf77b78bc5d3b6fa8b82b4ef68d6177',1,'IMediaWrapper::Stop()'],['../class_music_player.html#a3f900f8b7035c59770d3f6fa9cd2173c',1,'MusicPlayer::Stop()'],['../class_music_player_wrapper.html#a4f5d4ad5a9e1a8e2cacbe8d7c6503ee8',1,'MusicPlayerWrapper::Stop()'],['../class_video_player.html#a84e1e66483126d070b127ca1e96be954',1,'VideoPlayer::Stop()'],['../class_video_player_wrapper.html#ab213746516b9eed2f7ab4651236a23d0',1,'VideoPlayerWrapper::Stop()']]],
  ['switchnext_5',['SwitchNext',['../class_music_player.html#a70b76a99045ef74c70ff94c92923581f',1,'MusicPlayer']]]
];
