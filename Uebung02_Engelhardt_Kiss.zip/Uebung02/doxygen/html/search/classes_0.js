var searchData=
[
  ['boss_0',['Boss',['../class_boss.html',1,'']]]
];
