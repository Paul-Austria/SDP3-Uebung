var searchData=
[
  ['addemployee_0',['addemployee',['../class_employee_manager.html#a72f717846ca200315bf0fbae063a0b4d',1,'EmployeeManager::AddEmployee()'],['../class_i_employee_manager.html#a78a9c7ddffb5068b4eaf2273adb30323',1,'IEmployeeManager::AddEmployee()']]]
];
