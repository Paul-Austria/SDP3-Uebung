var searchData=
[
  ['delete_0',['delete',['../class_employee_manager.html#a740556d9a6c467fde5788e94182fba91',1,'EmployeeManager::Delete()'],['../class_i_employee_manager.html#a85c810bbbf9a19a00e731b46dd52ebe1',1,'IEmployeeManager::Delete()']]]
];
