var indexSectionsWithContent =
{
  0: "abcdeghimops",
  1: "bcehiop",
  2: "abcdeghmps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

