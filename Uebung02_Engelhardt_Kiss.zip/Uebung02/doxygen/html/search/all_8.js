var searchData=
[
  ['managertest_0',['ManagerTest',['../class_client.html#a657d1911c38b8ac51dd8dd6c86b72efd',1,'Client']]]
];
