var searchData=
[
  ['boss_0',['Boss',['../class_boss.html#a990d6d515d85fb1dbe2e9015f7909a74',1,'Boss']]]
];
