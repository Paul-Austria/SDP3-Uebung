/* File: Object.h
* Creator: Harald Kiss
*/
#ifndef OBJECT_H
#define OBJECT_H

class Object {

public:
	
	virtual ~Object() = default;

protected:
	
	Object() = default;

private:

};

#endif
